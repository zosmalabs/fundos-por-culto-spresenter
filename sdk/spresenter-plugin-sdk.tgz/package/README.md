# @spresenter/plugin-sdk

Official SDK for building **Spresenter** plugins.

The package version tracks the Spresenter app version (currently `0.2.11`).

## Model

A plugin runs in **two threads**, like Figma:

| Thread | File | Environment | Talks to |
|--------|------|-------------|----------|
| **Logic** | `code.ts` | Isolated process, no DOM | The app, via the global `spresenter` |
| **UI** | `ui/` | Sandboxed `<iframe>` | Only `code.ts`, via `postMessage` |

The UI never talks to the app or the host directly. Every privileged call
originates in the logic thread and is checked against the plugin's declared
`permissions` before reaching the app. Under the hood, each SDK method maps 1:1
to the same core that powers the Spresenter public REST API (`/api/v1`) — no
business logic is reimplemented on the plugin side.

```
UI (iframe) ⇄ postMessage ⇄ code.ts ⇄ host ⇄ app cores (live, assets, media, timer…)
```

## Entry points

```ts
// Logic thread — types only; the runtime is injected by the host.
import '@spresenter/plugin-sdk/code';

spresenter.assets.search('amazing grace', { type: 'music' });
spresenter.live.apply('0', 0, presentation);
spresenter.on('live', ({ output }) => { /* re-fetch */ });
```

```ts
// UI thread — real runtime, bundled into your UI build.
import { postMessage, onMessage } from '@spresenter/plugin-sdk/ui';

postMessage({ type: 'go-live', guid });
const off = onMessage((msg) => { /* messages from code.ts */ });
```

## `spresenter` API (logic thread)

| Namespace | Methods | Scope |
|-----------|---------|-------|
| `outputs` | `list()` | `outputs:read` |
| `layers` | `list()` | `outputs:read` |
| `live` | `read`, `readState`, `apply`, `clear`, `setState`, `setMaster`, `setMusicVerse`, `setElement`, `readElements`, `element` | `live:read` / `live:write` |
| `assets` | `get`, `list`, `search`, `getLyrics` | `assets:read` |
| `assets` | `createFile`, `createMusic`, `setLyrics`, `createFolder` | `assets:write` |
| `media` | `getState`, `play`, `pause`, `seek` | `media:read` / `media:write` |
| `timer` | `get`, `set`, `clear` | `timer:read` / `timer:write` |
| `setlists` | `getActive`, `list`, `get` | `setlists:read` |
| `setlists` | `create`, `rename`, `duplicate`, `delete`, `open`, `save`, `createNew`, `setTitle`, `items.*`, `groups.*` | `setlists:write` |
| `panels` | `list` | `ui:read` |
| `panels` | `open`, `close`, `select`, `dock`, `float` | `ui:write` |
| `thumbnails` | `render` | `assets:read` |
| `notifications` | `list` | `notifications:read` |
| `notifications` | `publish`, `markRead`, `markAllRead`, `remove`, `clear` | `notifications:write` |
| `requests` | `on`, `off`, `error` | — (this plugin's own actions) |
| `requests` | `call` | `plugins:invoke` |
| `plugins` | `list`, `get` | `plugins:read` |
| `lyrics` | `registerProvider` | — (needs `background: true`) |
| `automation` | `registerNode`, `registerCategory`, `registerTrigger`, `emitTrigger` | — (needs `background: true`) |
| `net` | `wsOpen`, `wsSend`, `wsClose`, `httpRequest`, `oscSend` | `net:connect` |
| `crypto` | `sha256Base64` | — |
| `storage` | `get`, `set`, `delete`, `keys` | — (per-plugin, isolated) |
| `on(event, cb)` | `live` \| `state` \| `media` \| `timer` \| `assets` \| `notification` | scope of the event |
| `ui` | `showPanel`, `showWindow`, `resize`, `close`, `postMessage`, `onmessage` | — |

Events are **notification-only**: the payload carries at most an `output` id;
fetch fresh data with the read methods after receiving one.

### Adding content to the library (`assets:write`)

A plugin can put content into Spresenter, not just read it. The host owns the
whole ingestion pipeline — thumbnail, ID3 tags, video normalization, SQLite
insert, FTS index — so a plugin never writes to disk itself.

```ts
// A file: bytes as base64 (or `sourceUrl`, which also needs `net:connect`).
const bg = await spresenter.assets.createFile({
  filename: 'opening.mp4',
  contentBase64,
  type: 'backgroundVideo',   // default for .mp4 would be 'video'
  parent: folder.guid,       // optional: organize it
});

// A song with STRUCTURED lyrics — this is what the app projects.
const { asset } = await spresenter.assets.createMusic({
  title: 'Sample Song',
  artist: ['Sample Author'],
  groups: [{ id: 'v', name: 'Verse', color: '#4f8cff' }],
  sections: [
    { type: 'verse', text: 'This is line one\nAnd this is line two', group: 'v' },
    { type: 'chorus', text: 'This is the chorus' },
  ],
});
```

Sections are **authoritative**: the searchable text is derived from them, so the
song is findable in Spotlight right away. Unknown section types, chord positions
outside the text and malformed group colors are dropped by the host — send the
payload and read back `lyrics` to see what was stored.

Uploaded video may still be re-encoded in the **background** (the returned
`extension` can change when it finishes) — listen to `on('assets', …)` if that
matters to you.

### Building the setlist (`setlists:write`)

Two different things live under `setlists`: the **library** of saved `.spe` files
and the **active** setlist — the one being edited, whose schedule the operator
sees in the sidebar. Writing to the active one goes through the app's own store,
so the UI updates as you call.

```ts
// Library: create, then make it the active one.
const saved = await spresenter.setlists.create({ title: 'Sunday, 10am' });
await spresenter.setlists.open(saved.id);

// Build the schedule. No `group` → the item gets a new group of its own.
const { group } = await spresenter.setlists.groups.add({ title: 'Worship' });
for (const song of songs) {
  await spresenter.setlists.items.add({ assetGuid: song.guid, group });
}

// Reorder (inside a group or across groups; 'orphans' is the loose list).
await spresenter.setlists.items.move({ group, index: 3 }, { group, index: 0 });

// Select an item — preview + the type's View, exactly like clicking the sidebar.
await spresenter.setlists.items.select({ group, index: 0 });

await spresenter.setlists.save();     // rejects if writing the file fails
```

`items.select` **does not project** — it prepares. Going live is
`live.setMusicVerse` (or the `.../present` route), which is where theme per
verse, background per verse and the selected outputs get resolved.

`open` and `createNew` **discard** whatever was being edited, with no
confirmation dialog: there is no operator on the other side of an API call. Call
`save()` first if the work matters.

### Driving the panels (`ui:write`)

The control app's layout is a dock of panels. A plugin can prepare the screen for
what it is about to do — open the Bible panel, bring Media Control into view,
dock its own panel next to the preview.

```ts
const { panels } = await spresenter.panels.list();   // ids, titles, open/visible, where

await spresenter.panels.open('bible');               // app's preferred position
await spresenter.panels.select('mediaControl');      // make it the ACTIVE tab
await spresenter.panels.dock(`plugin:${spresenter.manifest.id}:main`, {
  reference: 'preview',
  direction: 'within',                               // as a sibling tab
});
```

`select` is the one to reach for: a panel open as an **inactive tab** is as
invisible as a closed one, and `select` also leaves another group's fullscreen if
one is up. Panels gated by licence/configuration (mixer and fx without PRO, the
automation console when disabled) report `gated: true` and refuse to open.

### Becoming a lyric provider

A plugin can answer the app's **music search** and supply the lyrics of the song
the user picks, alongside the built-in catalog. This is the shape for a church's
own song archive or a subscription service — and it needs **no UI**.

```ts
spresenter.lyrics.registerProvider({
  id: 'main',
  name: 'Our archive',
  icon: 'music',
  priority: 10,                       // plugin providers already rank above the built-in catalog

  // Runs while the user types. Return your listing.
  search: async ({ query }) => (await findSongs(query)).map((s) => ({
    id: s.id,                         // opaque to Spresenter; comes back in getLyrics
    name: s.title,
    artists: [s.artist],
    isrc: s.isrc,
  })),

  // Runs when a song is selected. `id` is present when the row was YOURS.
  getLyrics: async ({ title, artist, isrc, id }) => {
    const song = await loadSong({ id, isrc, title, artist });
    if (!song) return null;           // "I don't have this one" — not an error
    return { sections: song.blocks.map((text) => ({ type: 'verse', text })) };
  },
});
```

- **`background: true` is required.** A provider only exists once your `code.js`
  has run, and the app cannot know a stopped plugin would be one. Register at the
  **top level**, not after an `await`.
- **Return `sections`, not a flat `lyrics` array**, whenever your source has
  structure: sections are what the app projects (one slide each), they carry the
  section type, groups, chords and comments, and the searchable text is derived
  from them. The app marks providers that return structured lyrics with a `✦`.
- **Nothing you return is trusted blindly.** The host normalizes and caps the
  payload, drops unknown section types and out-of-range chord positions, and
  treats empty lyrics as "not found". A provider that throws, times out or is not
  running simply contributes nothing — it never blocks the search box.
- Omit `search` to be a **lyrics-only** provider: you are still asked for the
  lyrics of songs listed by others (matching on `isrc`/title), but contribute no
  rows of your own.
- Needs a login? Add a panel, store the token with `spresenter.storage`, and read
  it inside the callbacks. Scaffold **Settings → Plugins → Create plugin… →
  Lyric provider** for a working starting point.

### Talking to the operator (`notifications:write`)

`spresenter.notifications` is the **notification center** — the bell in the title
bar, the same place where messages sent from the Spresenter dashboard land. It is
how a plugin says something to whoever is running the service:

```ts
await spresenter.notifications.publish({
  title: 'Schedule changed',
  body: 'Ana replaced João on camera 2.',
  level: 'warning',                   // info | success | warning | error
});
```

- The card enters the center, flashes as a **toast** right away, and — only when
  the window is **not focused** — also fires an OS notification. With the app in
  front, the toast and the bell already say it, and on Windows a native
  notification steals keyboard focus mid-service.
- It does **not** disappear on its own. Whoever published decides when to
  `remove(id)`; an auto-clear would hide the message from exactly the person
  whose hands were busy when it arrived.
- Pass your own `id` to make a re-send idempotent — the center dedupes by it.
- `from` defaults to your plugin's name. An anonymous alert during a service
  doesn't tell anyone who to ask about it.
- Subscribe with `spresenter.on('notification', …)` (needs `notifications:read`)
  to forward what arrives somewhere else — the team's radio, a chat group.

### Being called from outside (`requests`)

The `/api/v1` REST API covers what the **app** can do. What a third-party system
usually needs is something only *your* plugin knows how to do — "pull today's
schedule", "sync with my system", "tell them the service is running late".

`spresenter.requests.on(action, handler)` makes this machine answer
`POST /api/v1/plugins/<your id>/requests/<action>`. The request body arrives as
the payload; whatever you return is the HTTP response. Nothing in between is
interpreted by the app.

```ts
spresenter.requests.on(
  'sync',
  async (payload, meta) => {
    // meta: { method: 'GET' | 'POST' | 'PLUGIN', query, token }
    const member = await lookup(payload.memberId);
    if (!member) throw spresenter.requests.error(404, 'Member not found');
    return { synced: true, name: member.name };
  },
  { name: 'Sync schedule', description: "Pulls today's roster", sample: { memberId: '42' } },
);
```

- **This is also how the cloud reaches you.** The Spresenter server forwards
  `/api/v1` calls to the connected machine over its realtime channel, so an
  integration on the internet reaches your plugin without it opening a port or
  keeping a connection of its own. The call still goes through the machine's own
  `authenticate`, scopes and the "external API enabled" gate.
- **Register at the top level of `code.js`.** When a call wakes a stopped plugin,
  the host runs the whole file and dispatches right after — a registration behind
  an `await` would not be there in time. With `background: true` the action also
  shows up in `GET /api/v1/plugins` before anyone has called it.
- **The caller needs the `plugins:invoke` scope**; you need nothing extra to
  register. What the handler *does* is still limited by the permissions you
  declared.
- **You choose the failure status.** `throw spresenter.requests.error(404, …)`
  answers 404; a plain `throw` is 500. Not answering is not an option — an
  unknown action replies 404 by itself, so no caller is left hanging.
- A `GET` on the same route passes the **query string** as the payload, for
  callers that can only emit a URL.
- `spresenter.requests.call(pluginId, action, payload)` invokes **another**
  plugin's action through the same bridge (needs `plugins:invoke`).

## UI kit (shared components)

So every plugin looks like a native part of Spresenter instead of styling its
own widgets, the SDK ships a shared design system that matches the host theme.

```ts
// One stylesheet, two component flavours — pick the one your UI is built with.
import { injectStyles } from '@spresenter/plugin-sdk/ui-kit';

// React plugins:
import { Root, Header, Panel, Field, TextInput, Button, Segmented }
  from '@spresenter/plugin-sdk/ui-kit/react';

// Vanilla (no framework) plugins — same names, DOM-node factories:
import { Root, Header, Field, TextInput, Button } from '@spresenter/plugin-sdk/ui-kit';

injectStyles(); // once at startup (idempotent)
```

Components: `Root`, `Header`, `Panel`, `Row`, `Stack`, `Field`, `TextInput`,
`TextArea`, `Select`, `Checkbox`, `Button` (`primary`/`secondary`/`success`/`danger`/`ghost`),
`Actions`, `Segmented`, `StatusIndicator`, `Alert`, `Footer`, `Hint`. All are
driven by `sp-*` CSS classes and CSS variables you can override.

## Manifest

```json
{
  "id": "com.example.my-plugin",
  "name": "My Plugin",
  "version": "0.2.11",
  "minAppVersion": "0.2.11",
  "sdk": "0.2.11",
  "main": "dist/code.js",
  "ui": "dist/ui/index.html",
  "permissions": ["outputs:read", "assets:read", "assets:write", "live:write"],
  "panels": [{ "id": "main", "title": "My Plugin", "icon": "puzzle" }]
}
```

- `permissions` must be a subset of the scopes above; unknown scopes fail install.
- `panels` declare docked tabs inside the app (rendered without running code).
- `ui` can also be shown as a floating window via `spresenter.ui.showWindow()`.

## Scaffolding

The fastest way to start is **Settings → Plugins → Create plugin…** inside
Spresenter, which generates a ready-to-build project (Vite + Tailwind + this SDK)
from the official template.

## Build

```bash
npm install
npm run build   # emits dist/ (ui.js, ui.cjs, protocol.js, protocol.cjs, d.ts)
```

## License

MIT.
