// Type declarations for the global `spresenter` available inside a plugin's
// logic thread (code.ts). This entrypoint ships TYPES ONLY — the runtime is
// injected by the host, mirroring @figma/plugin-typings. Import it for its
// side-effect of declaring the global:
//
//   import '@spresenter/plugin-sdk/code';
//
// Every method maps 1:1 to a host core that the /api/v1 REST API also uses;
// no business logic is reimplemented plugin-side.

import type {
  OutputSummary,
  LayerSummary,
  LayerState,
  Asset,
  AssetFilters,
  Lyrics,
  Presentation,
  MediaState,
  TimerState,
  SetlistSummary,
  ActiveSetlist,
  SetlistGroupRef,
  SetlistItemRef,
  AddSetlistItemInput,
  SelectSetlistItemInput,
  SetlistGroupPatch,
  PanelInfo,
  OpenPanelOptions,
  CompositionSummary,
  PluginManifest,
  AutomationNodeDef,
  AutomationCategoryDef,
  AutomationTriggerDef,
  ElementPatch,
  ElementHandle,
  CreateAssetFileInput,
  CreateMusicInput,
  SetLyricsInput,
  CreateFolderInput,
  LyricProviderDef,
  AppNotification,
  PublishNotificationInput,
  PluginRequestMeta,
  PluginRequestDef,
  PluginSummary,
} from '../src/types/domain';

export type PluginEventName =
  | 'live'
  | 'state'
  | 'media'
  | 'timer'
  | 'assets'
  /** A notification landed in this machine's center (panel, API or a plugin). */
  | 'notification';

/** One typed OSC argument: string, float or int (`net.oscSend`). */
export interface OscArg {
  type: 's' | 'f' | 'i';
  value: string | number;
}

export interface SpresenterApi {
  /** The parsed manifest.json of this plugin. */
  readonly manifest: PluginManifest;

  outputs: {
    list(): Promise<OutputSummary[]>;
  };
  layers: {
    list(): Promise<LayerSummary[]>;
  };
  live: {
    read(output: string): Promise<(Presentation | null)[]>;
    readState(output: string): Promise<LayerState[]>;
    apply(output: string, layer: number, presentation: Presentation): Promise<void>;
    clear(output: string, layer: number): Promise<void>;
    setState(output: string, layer: number, patch: Partial<LayerState>): Promise<LayerState>;
    setMaster(output: string, opacity: number): Promise<{ opacity: number }>;
    setMusicVerse(output: string, layer: number, assetGuid: string, index: number): Promise<void>;
    /** Control a live theme element by id in real time (no theme reload). */
    setElement(output: string, layer: number, elementId: string, patch: ElementPatch): Promise<void>;
    /** Current element overrides of an output: `{ [layer]: { [elementId]: patch } }`. */
    readElements(output: string): Promise<Record<string, Record<string, ElementPatch>>>;
    /** Grab a live element and modify it freely (chainable): `element(...).setText(...).setStyle(...)`. */
    element(output: string, layer: number, elementId: string): ElementHandle;
  };
  assets: {
    get(guid: string): Promise<Asset | null>;
    list(filters?: AssetFilters): Promise<Asset[]>;
    search(q: string, filters?: AssetFilters): Promise<Asset[]>;
    getLyrics(guid: string): Promise<Lyrics | null>;

    // ── Criação (requer a permissão `assets:write`) ──────────
    /** Add a file to the library. Bytes go in `contentBase64`; `sourceUrl` makes
     *  the HOST download it (and needs `net:connect` as well). Video is
     *  normalized like any other upload — a cheap remux runs inline and a costly
     *  re-encode goes to the background queue, so the returned `extension` may
     *  still change later (watch the `assets` event). */
    createFile(input: CreateAssetFileInput): Promise<Asset>;
    /** Create a song with STRUCTURED lyrics — sections (verse/chorus/…), groups,
     *  chords and timecodes. The host validates the payload and derives the
     *  searchable text from the sections, so FTS keeps working. */
    createMusic(input: CreateMusicInput): Promise<{ asset: Asset; lyrics: Lyrics }>;
    /** Replace the structured lyrics of an existing song. */
    setLyrics(guid: string, input: SetLyricsInput): Promise<Lyrics>;
    /** Create a folder, to keep what the plugin adds organized. */
    createFolder(input: CreateFolderInput): Promise<Asset>;
  };
  media: {
    getState(): Promise<MediaState>;
    play(): Promise<void>;
    pause(): Promise<void>;
    seek(time: number): Promise<void>;
  };
  timer: {
    get(): Promise<TimerState>;
    set(patch: Partial<TimerState>): Promise<TimerState>;
    clear(): Promise<TimerState>;
  };
  /**
   * Setlists — a biblioteca de arquivos salvos E a setlist ATIVA (a que está em
   * edição, cuja programação o operador vê na sidebar).
   *
   * Leitura pede `setlists:read`; tudo que escreve pede `setlists:write`.
   * A escrita passa pelo MESMO núcleo das rotas `/api/v1/setlist(s)`, então o
   * comportamento é idêntico ao da API REST.
   */
  setlists: {
    getActive(): Promise<ActiveSetlist | null>;
    list(): Promise<SetlistSummary[]>;
    /** Uma setlist SALVA, completa. */
    get(id: string): Promise<ActiveSetlist>;

    // ── Biblioteca (arquivos .spe) ──────────────────────────
    /** Cria uma setlist VAZIA na biblioteca (não a ativa). */
    create(input?: { title?: string; description?: string; init?: string }): Promise<SetlistSummary>;
    rename(id: string, title: string): Promise<{ id: string; title: string }>;
    duplicate(id: string): Promise<SetlistSummary>;
    delete(id: string): Promise<{ id: string; deleted: true }>;
    /** Torna uma setlist salva a ATIVA — descarta o que estava em edição (não há
     *  diálogo de confirmação: quem chama pela API já decidiu). */
    open(id: string): Promise<{ id: string | null; title: string }>;

    // ── Setlist ativa ───────────────────────────────────────
    /** Grava a setlist ativa na biblioteca. Rejeita se a gravação falhar. */
    save(): Promise<{ id: string | null; title: string }>;
    /** Descarta a ativa e começa uma em branco. */
    createNew(title?: string): Promise<{ id: string | null; title: string }>;
    /** Renomeia a setlist ativa. */
    setTitle(title: string): Promise<{ id: string | null; title: string }>;

    /** Itens da programação da setlist ativa. */
    items: {
      /** Adiciona um asset. Sem `group`, nasce um grupo novo com ele dentro. */
      add(input: AddSetlistItemInput): Promise<SetlistItemRef>;
      remove(group: SetlistGroupRef, index: number): Promise<{ removed: true }>;
      /** Reordena — dentro do grupo ou entre grupos (inclui os soltos). */
      move(from: SetlistItemRef, to: SetlistItemRef): Promise<{ from: SetlistItemRef; to: SetlistItemRef }>;
      /** Seleciona: prévia + View do tipo, o mesmo do clique na sidebar. NÃO
       *  projeta — pôr no ar é `live.setMusicVerse` / a rota `.../present`. */
      select(target: SelectSetlistItemInput): Promise<unknown>;
    };

    /** Grupos da programação da setlist ativa. */
    groups: {
      add(input?: { title?: string; assetGuids?: string[] }): Promise<{ group: number; title: string }>;
      update(group: number, patch: SetlistGroupPatch): Promise<unknown>;
      remove(group: number): Promise<{ removed: true }>;
      /** Move o grupo para outra posição na programação. */
      move(group: number, to: number): Promise<{ group: number; to: number }>;
    };
  };
  /** @deprecated renamed to `setlists` — still works (leitura só). */
  events: {
    getActive(): Promise<ActiveSetlist | null>;
    list(): Promise<SetlistSummary[]>;
  };
  /**
   * Painéis da dock do app de controle — abrir, fechar, **selecionar** (tornar a
   * aba ativa do grupo) e **ancorar** um flutuante.
   *
   * `ui:read` para listar, `ui:write` para mexer. Não confundir com `ui.*`, que é
   * a janela/painel DESTE plugin.
   *
   * Ids: os do núcleo (`preview`, `live`, `media`, `bible`, `mixer`, `fx`,
   * `mediaControl`, `properties`, `announcements`, `timers`, `macroButtons`,
   * `console`, `stage`, `sidebar`, `main`), `plugin:<pluginId>:<panelId>`,
   * `live:<saída>`, `mixer:<saída>` e `custom:<id>`. `panels.list()` é a fonte.
   */
  panels: {
    list(): Promise<{ panels: PanelInfo[] }>;
    open(id: string, opts?: OpenPanelOptions): Promise<PanelInfo>;
    close(id: string): Promise<{ id: string; closed: true }>;
    /** Traz à vista: abre se preciso, seleciona a aba, sai da tela cheia de outro
     *  grupo. Um painel aberto como aba INATIVA é invisível — este é o comando. */
    select(id: string): Promise<PanelInfo>;
    /** Ancora na dock. Sem `reference`, vai para o primeiro grupo ancorado. */
    dock(id: string, opts?: { reference?: string; direction?: OpenPanelOptions['direction'] }): Promise<PanelInfo>;
    /** Solta num grupo flutuante (o inverso de `dock`). */
    float(id: string, opts?: { width?: number; height?: number; x?: number; y?: number }): Promise<PanelInfo>;
  };
  /**
   * Composições (cenas): o retrato das camadas atuais — definições, mixer, rack
   * de efeitos, master e o conteúdo de cada camada, por saída.
   *
   * `list()` é acervo (`assets:read`). `open()` REPÕE tudo isso (inclusive as
   * definições de camada do app) e não pergunta nada: é `live:write`, e é o
   * mesmo núcleo de `POST /api/v1/compositions/:guid/open`.
   *
   * Saída que a cena não conhece fica intocada; saída da cena que não existe
   * nesta máquina é ignorada — os dois casos voltam contados na resposta.
   */
  compositions: {
    list(): Promise<{ compositions: CompositionSummary[] }>;
    open(guid: string): Promise<CompositionSummary & {
      opened: true;
      extraInComposition: number;
      extraInApp: number;
    }>;
  };
  /**
   * Central de notificações desta máquina — o sino da barra de título, o mesmo
   * lugar onde caem as mensagens enviadas pelo painel do Spresenter.
   *
   * `publish` é como um plugin FALA com quem está operando: o cartão entra na
   * central, aparece como toast na hora e, com a janela fora de foco, vira
   * notificação do sistema operacional. Não some sozinho — quem publicou decide
   * quando remover.
   *
   * Ler pede `notifications:read`; publicar/marcar/apagar pedem
   * `notifications:write`.
   */
  notifications: {
    /** A central, mais recente primeiro, com o total de não lidas. */
    list(opts?: { unreadOnly?: boolean; limit?: number }): Promise<{
      notifications: AppNotification[];
      unread: number;
    }>;
    /** Publica um aviso nesta máquina. `from` assume o nome do plugin. */
    publish(input: PublishNotificationInput): Promise<AppNotification>;
    markRead(id: string): Promise<{ id: string; read: true }>;
    markAllRead(): Promise<{ read: number }>;
    remove(id: string): Promise<{ id: string; removed: true }>;
    /** Esvazia a central. */
    clear(): Promise<{ cleared: number }>;
  };
  /**
   * **Ações que este plugin expõe por id único.**
   *
   * Registrar `'sync'` faz esta máquina atender
   * `POST /api/v1/plugins/<seu id>/requests/sync` — e como o servidor do
   * Spresenter encaminha chamadas `/api/v1` para a máquina conectada, um sistema
   * de terceiros alcança o seu plugin de qualquer lugar, sem ele abrir porta nem
   * manter conexão própria. O corpo da chamada chega como `payload`; o que você
   * devolver é a resposta HTTP.
   *
   * Registre no TOPO do `code.js`: quando a chamada acorda um plugin parado, o
   * app roda o arquivo inteiro e despacha em seguida — um registro depois de um
   * `await` não estaria lá a tempo. Com `background: true` no manifesto a ação
   * também aparece em `GET /api/v1/plugins` antes da primeira chamada.
   */
  requests: {
    /**
     * Atende `.../requests/<action>`. O handler recebe o corpo (ou a query, num
     * `GET`) e o `meta` da chamada.
     */
    on(
      action: string,
      handler: (payload: any, meta: PluginRequestMeta) => unknown | Promise<unknown>,
      meta?: PluginRequestDef,
    ): void;
    /** Deixa de atender uma ação. */
    off(action: string): void;
    /**
     * Erro com status HTTP escolhido por você. Jogue-o de dentro do handler para
     * que quem chamou receba 404/400/409 em vez de um 500 genérico:
     * `throw spresenter.requests.error(404, 'Membro não encontrado')`.
     */
    error(status: number, message: string, code?: string): Error;
    /** Chama uma ação de OUTRO plugin (requer `plugins:invoke`). */
    call(
      pluginId: string,
      action: string,
      payload?: unknown,
      opts?: { timeoutMs?: number },
    ): Promise<{ pluginId: string; action: string; data: unknown }>;
  };
  /** Plugins instalados nesta máquina e as ações que cada um expõe
   *  (`plugins:read`). Não confundir com `requests`, que é o seu lado. */
  plugins: {
    list(): Promise<{ plugins: PluginSummary[] }>;
    get(pluginId: string): Promise<PluginSummary>;
  };
  thumbnails: {
    render(presentation: Presentation, width: number, height: number): Promise<string | null>;
  };
  /**
   * Become a **lyric provider**: the plugin answers the app's music search and
   * supplies the lyrics of the song the user picks, side by side with the
   * built-in catalog. No UI is required — a provider is pure logic (add a panel
   * only if your service needs a login).
   *
   * Requires `background: true` in the manifest. A provider only exists once
   * your `code.js` has run, and the app cannot know a stopped plugin would be
   * one — so without `background` it is never consulted.
   */
  lyrics: {
    registerProvider(def: LyricProviderDef): void;
  };
  /** Register custom nodes in the automation editor. Requires `background: true`
   *  in the manifest so the node is available even without any UI open. */
  automation: {
    registerNode(def: AutomationNodeDef): void;
    /** Declare a custom category (label + icon) for the "add node" menu, so
     *  this plugin's nodes group under their own section instead of "plugins". */
    registerCategory(def: AutomationCategoryDef): void;
    /** Declare a trigger that this plugin fires. It shows up in the trigger
     *  list; fire it at runtime with emitTrigger(). */
    registerTrigger(def: AutomationTriggerDef): void;
    /** Fire a previously-registered trigger, running matching automations with
     *  this payload (trigger nodes can filter on the payload's fields). */
    emitTrigger(triggerId: string, payload?: Record<string, unknown>): void;
  };
  /** Generic outbound network (requires the `net:connect` permission). Sockets
   *  live in the host. WebSocket events arrive via `net.on(connId, type, cb)`;
   *  `httpRequest` is one-shot request/response. Lets a plugin speak protocols
   *  like obs-websocket or HTTP WebServices/REST entirely on its own. */
  net: {
    /** Open a WebSocket (ws:// or wss://). Resolves with a connection id. */
    wsOpen(url: string): Promise<string>;
    /** Send a text frame on an open connection. */
    wsSend(connId: string, data: string): Promise<boolean>;
    /** Close a connection. */
    wsClose(connId: string): Promise<boolean>;
    /** Listen to a connection's lifecycle. For `type:'message'`, the event's
     *  `data` holds the frame text. Register right after `wsOpen` resolves. */
    on(
      connId: string,
      type: 'open' | 'message' | 'close' | 'error',
      cb: (e: { connId: string; type: string; data?: string; code?: number; message?: string }) => void,
    ): void;
    /** One-shot HTTP request (any method). Never throws on 4xx/5xx — the status
     *  is returned so the plugin can react. Ideal for HTTP WebServices/REST APIs. */
    httpRequest(opts: {
      method?: string;
      url: string;
      headers?: Record<string, string>;
      body?: string;
      timeoutMs?: number;
    }): Promise<{ ok: boolean; status: number; statusText: string; body: string; error?: string }>;
    /** Send one OSC message over UDP (fire-and-forget: there is no reply and no
     *  return path — the host just writes the datagram). Rejects only when the
     *  local send fails (bad address/host/port, socket unavailable); delivery to
     *  the target is never confirmed. Typical use: lighting consoles, e.g.
     *  `oscSend('192.168.0.10', 8000, '/cmd', [{ type: 's', value: 'Go+ Executor 1.201' }])`. */
    oscSend(host: string, port: number, address: string, args?: OscArg[]): Promise<boolean>;
  };
  /** Small crypto helpers (e.g. for auth handshakes). */
  crypto: {
    /** SHA-256 of a UTF-8 string, base64-encoded. */
    sha256Base64(input: string): Promise<string>;
  };
  /** Per-plugin persistent key/value storage (isolated per plugin). */
  storage: {
    get<T = unknown>(key: string): Promise<T | undefined>;
    set(key: string, value: unknown): Promise<void>;
    delete(key: string): Promise<void>;
    keys(): Promise<string[]>;
  };
  /** Subscribe to live/state/media/timer/assets/notification events. Returns an
   *  unsubscribe fn. Events are notification-only; fetch fresh data via the
   *  methods above. `assets` fires whenever the library changes — including when
   *  a background re-encode swaps the file of a video you uploaded; `notification`
   *  fires when something lands in the notification center (read it with
   *  `notifications.list()` — requires `notifications:read`). */
  on(event: PluginEventName, cb: (payload: { output?: string }) => void): () => void;
  ui: {
    /** Focus/open this plugin's docked panel tab. */
    showPanel(panelId?: string): Promise<void>;
    /** Open this plugin's UI in a floating native window. */
    showWindow(opts?: { width?: number; height?: number; title?: string }): Promise<void>;
    /** Resize the floating window (if open). */
    resize(width: number, height: number): Promise<void>;
    /** Close the plugin's floating window / UI surface. */
    close(): Promise<void>;
    /** Send a message to the plugin UI (iframe). */
    postMessage(msg: unknown): void;
    /** Assign a handler for messages coming from the plugin UI. */
    onmessage: ((msg: unknown) => void) | undefined;
  };
  /** Terminate the plugin's logic process. */
  closePlugin(): void;
}

declare global {
  const spresenter: SpresenterApi;
}

export {};
