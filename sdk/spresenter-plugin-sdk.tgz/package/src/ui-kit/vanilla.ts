// Framework-agnostic UI components for plugin UIs built without React
// (plain HTML/JS panels). Each factory returns a real DOM element styled with
// the shared `sp-*` classes, so a vanilla plugin looks identical to a React one.
//
//   import { injectStyles, Root, Header, Field, TextInput, Button }
//     from '@spresenter/plugin-sdk/ui-kit';
//
//   injectStyles();
//   const host = TextInput({ id: 'host', value: '127.0.0.1' });
//   document.body.append(
//     Root(
//       Header({ title: 'OBS Studio', subtitle: 'Connect to obs-websocket.' }),
//       Field({ label: 'Host', control: host }),
//     ),
//   );

export type ButtonVariant = 'primary' | 'secondary' | 'success' | 'danger' | 'ghost';
export type StatusState = 'idle' | 'ok' | 'warn' | 'connecting' | 'error';

type Child = Node | string | null | undefined | false;

/** Minimal hyperscript helper: create an element with props + children. */
export function el<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  props: Record<string, unknown> = {},
  ...children: Child[]
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value == null || value === false) continue;
    if (key === 'className') node.className = String(value);
    else if (key === 'style' && typeof value === 'object') {
      Object.assign(node.style, value as object);
    } else if (key.startsWith('on') && typeof value === 'function') {
      node.addEventListener(key.slice(2).toLowerCase(), value as EventListener);
    } else if (key in node) {
      (node as Record<string, unknown>)[key] = value;
    } else {
      node.setAttribute(key, String(value));
    }
  }
  append(node, children);
  return node;
}

function append(node: Node, children: Child[]): void {
  for (const child of children.flat() as Child[]) {
    if (child == null || child === false) continue;
    node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
  }
}

/** Root screen wrapper (dark background, padding, vertical stack). */
export function Root(...children: Child[]): HTMLDivElement {
  return el('div', { className: 'sp-root' }, ...children);
}

/** Title + optional subtitle header. */
export function Header(opts: { title: string; subtitle?: string }): HTMLElement {
  return el(
    'header',
    { className: 'sp-header' },
    el('h1', { className: 'sp-header__title' }, opts.title),
    opts.subtitle ? el('p', { className: 'sp-header__subtitle' }, opts.subtitle) : null,
  );
}

/** Grouped card with an optional uppercase label. */
export function Panel(opts: { label?: string; children?: Child[] } = {}): HTMLDivElement {
  return el(
    'div',
    { className: 'sp-panel' },
    opts.label ? el('span', { className: 'sp-panel__label' }, opts.label) : null,
    ...(opts.children ?? []),
  );
}

/** Horizontal flex row. */
export function Row(...children: Child[]): HTMLDivElement {
  return el('div', { className: 'sp-row' }, ...children);
}

/** Vertical flex stack. */
export function Stack(...children: Child[]): HTMLDivElement {
  return el('div', { className: 'sp-stack' }, ...children);
}

/** Labeled control wrapper. `control` is any element (input, select, …). */
export function Field(opts: {
  label: string;
  control: HTMLElement;
  hint?: string;
  grow?: number;
}): HTMLLabelElement {
  const field = el(
    'label',
    { className: 'sp-field' },
    el('span', { className: 'sp-field__label' }, opts.label),
    opts.control,
    opts.hint ? el('span', { className: 'sp-field__hint' }, opts.hint) : null,
  );
  if (opts.grow != null) field.style.flex = String(opts.grow);
  return field;
}

/** Text / number / password input. */
export function TextInput(opts: {
  id?: string;
  type?: string;
  value?: string | number;
  placeholder?: string;
  disabled?: boolean;
  onInput?: (value: string, ev: Event) => void;
} = {}): HTMLInputElement {
  const input = el('input', {
    className: 'sp-input',
    type: opts.type ?? 'text',
    id: opts.id,
    value: opts.value ?? '',
    placeholder: opts.placeholder ?? '',
    disabled: opts.disabled,
  });
  if (opts.onInput) {
    input.addEventListener('input', (ev) => opts.onInput!(input.value, ev));
  }
  return input;
}

/** Multi-line text input. */
export function TextArea(opts: {
  id?: string;
  value?: string;
  rows?: number;
  placeholder?: string;
  mono?: boolean;
  onInput?: (value: string, ev: Event) => void;
} = {}): HTMLTextAreaElement {
  const ta = el('textarea', {
    className: `sp-textarea${opts.mono ? ' sp-textarea--mono' : ''}`,
    id: opts.id,
    rows: opts.rows ?? 4,
    value: opts.value ?? '',
    placeholder: opts.placeholder ?? '',
  });
  if (opts.onInput) ta.addEventListener('input', (ev) => opts.onInput!(ta.value, ev));
  return ta;
}

/** Dropdown select. */
export function Select(opts: {
  id?: string;
  value?: string;
  options: Array<{ value: string; label: string }>;
  disabled?: boolean;
  onChange?: (value: string, ev: Event) => void;
} = { options: [] }): HTMLSelectElement {
  const select = el(
    'select',
    { className: 'sp-select', id: opts.id, disabled: opts.disabled },
    ...opts.options.map((o) =>
      el('option', { value: o.value, selected: o.value === opts.value }, o.label),
    ),
  );
  if (opts.value != null) select.value = String(opts.value);
  if (opts.onChange) select.addEventListener('change', (ev) => opts.onChange!(select.value, ev));
  return select;
}

/** Checkbox with an inline label. */
export function Checkbox(opts: {
  id?: string;
  label: string;
  checked?: boolean;
  onChange?: (checked: boolean, ev: Event) => void;
}): HTMLLabelElement {
  const input = el('input', {
    className: 'sp-checkbox__input',
    type: 'checkbox',
    id: opts.id,
    checked: opts.checked,
  });
  if (opts.onChange) {
    input.addEventListener('change', (ev) => opts.onChange!(input.checked, ev));
  }
  return el('label', { className: 'sp-checkbox' }, input, el('span', {}, opts.label));
}

const BTN_VARIANT: Record<ButtonVariant, string> = {
  primary: 'sp-btn--primary',
  secondary: '',
  success: 'sp-btn--success',
  danger: 'sp-btn--danger',
  ghost: 'sp-btn--ghost',
};

/** Action button. Variant defaults to `secondary`. */
export function Button(opts: {
  id?: string;
  label: string;
  variant?: ButtonVariant;
  size?: 'sm' | 'md';
  disabled?: boolean;
  block?: boolean;
  onClick?: (ev: MouseEvent) => void;
}): HTMLButtonElement {
  const cls = [
    'sp-btn',
    BTN_VARIANT[opts.variant ?? 'secondary'],
    opts.size === 'sm' ? 'sp-btn--sm' : '',
    opts.block ? 'sp-btn--block' : '',
  ]
    .filter(Boolean)
    .join(' ');
  const btn = el('button', {
    className: cls,
    id: opts.id,
    type: 'button',
    disabled: opts.disabled,
  }, opts.label);
  if (opts.onClick) btn.addEventListener('click', opts.onClick as EventListener);
  return btn;
}

/** Button row. Pass `{ spacerBefore: true }` on a button-wrapping call is not
 *  supported here; instead append `actionsSpacer()` between groups. */
export function Actions(...buttons: Child[]): HTMLDivElement {
  return el('div', { className: 'sp-actions' }, ...buttons);
}

/** A flexible spacer to push subsequent buttons to the right inside Actions(). */
export function actionsSpacer(): HTMLSpanElement {
  return el('span', { className: 'sp-actions__spacer' });
}

/** Segmented control (mutually exclusive toggle buttons). */
export function Segmented(opts: {
  value: string;
  options: Array<{ value: string; label: string }>;
  onChange?: (value: string) => void;
}): HTMLDivElement & { setValue(v: string): void } {
  const buttons = new Map<string, HTMLButtonElement>();
  const render = (active: string) => {
    for (const [val, btn] of buttons) {
      btn.className =
        'sp-segmented__option' + (val === active ? ' sp-segmented__option--active' : '');
    }
  };
  const root = el(
    'div',
    { className: 'sp-segmented' },
    ...opts.options.map((o) => {
      const btn = el('button', { type: 'button' }, o.label);
      btn.addEventListener('click', () => {
        render(o.value);
        opts.onChange?.(o.value);
      });
      buttons.set(o.value, btn);
      return btn;
    }),
  );
  render(opts.value);
  return Object.assign(root, {
    setValue: (v: string) => render(v),
  });
}

/** Status indicator (colored dot + label + detail) with a live updater. */
export function StatusIndicator(opts: {
  state?: StatusState;
  label?: string;
  detail?: string;
} = {}): HTMLDivElement & {
  set(next: { state?: StatusState; label?: string; detail?: string }): void;
} {
  const dot = el('span', { className: 'sp-status__dot' });
  const label = el('span', { className: 'sp-status__label' }, opts.label ?? '');
  const detail = el('span', { className: 'sp-status__detail' }, opts.detail ?? '');
  const root = el('div', { className: 'sp-status' }, dot, label, detail);
  const set = (next: { state?: StatusState; label?: string; detail?: string }) => {
    if (next.state !== undefined) {
      root.className = 'sp-status' + (next.state !== 'idle' ? ` sp-status--${next.state}` : '');
    }
    if (next.label !== undefined) label.textContent = next.label;
    if (next.detail !== undefined) detail.textContent = next.detail;
  };
  set({ state: opts.state ?? 'idle' });
  return Object.assign(root, { set });
}

/** Inline colored message box. */
export function Alert(opts: {
  variant?: 'success' | 'error' | 'warning' | 'info';
  text: string;
  detail?: string;
}): HTMLDivElement {
  return el(
    'div',
    { className: `sp-alert sp-alert--${opts.variant ?? 'info'}` },
    el('div', {}, opts.text),
    opts.detail ? el('div', { className: 'sp-alert__detail' }, opts.detail) : null,
  );
}

/** Muted footer text. */
export function Footer(...children: Child[]): HTMLElement {
  return el('footer', { className: 'sp-footer' }, ...children);
}

/** Small muted hint text. */
export function Hint(text: string): HTMLSpanElement {
  return el('span', { className: 'sp-hint' }, text);
}
