// @spresenter/plugin-sdk/ui-kit — framework-agnostic entry.
//
// Ships the shared design-system stylesheet (matching the host app theme) plus
// vanilla DOM component factories, so every plugin UI looks like a native part
// of Spresenter instead of each one styling its own widgets from scratch.
//
// React plugins should import components from '@spresenter/plugin-sdk/ui-kit/react'
// (they share the exact same stylesheet — call injectStyles() from either entry).

export { injectStyles, uiKitCss } from './styles';
export * from './vanilla';
export type { ButtonVariant, StatusState } from './vanilla';
