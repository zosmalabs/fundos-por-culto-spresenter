// Public domain types exposed to plugins. These mirror the shapes the host
// returns from the API surface. They are intentionally loose where the app's
// internal model is dynamic — plugins should treat unknown fields defensively.

export interface OutputSummary {
  index: number;
  name: string;
  width?: number;
  height?: number;
  disabledLayers: number[];
}

export interface LayerSummary {
  index: number;
  name?: string;
  icon?: string;
}

export interface LayerState {
  show: boolean;
  opacity: number;
  blend: string;
  transitionMs?: number;
  [key: string]: unknown;
}

export interface Asset {
  guid: string;
  type: string;
  title?: string;
  author?: string;
  parent_guid?: string | null;
  category?: string | null;
  [key: string]: unknown;
}

export interface AssetFilters {
  type?: string;
  category?: string;
  /** undefined = no folder filter; null = category root; string = inside folder. */
  parent?: string | null;
}

/** A chord anchored at a character offset inside a section's text. */
export interface LyricChord {
  position: number;
  chord: string;
}

/** A free comment anchored at a character offset inside a section's text. */
export interface LyricComment {
  position: number;
  comment: string;
}

export type LyricSectionType =
  | 'verse'
  | 'pre-chorus'
  | 'chorus'
  | 'bridge'
  | 'intro'
  | 'outro'
  | 'instrumental'
  | 'tag'
  | 'ending';

/**
 * One projectable unit of a song (a verse, the chorus, …) — the structured form
 * of the lyrics. `text` holds the line breaks of the slide; unknown `type`s and
 * out-of-range chord/comment positions are dropped by the host on write.
 */
export interface LyricSection {
  type?: LyricSectionType;
  text: string;
  chords?: LyricChord[];
  comments?: LyricComment[];
  /** id of a MusicGroup in `groups`. */
  group?: string;
}

/** A named (optionally colored) group of sections, e.g. "Verse 1". */
export interface MusicGroup {
  id: string;
  name: string;
  /** `#rgb` … `#rrggbbaa`; anything else is dropped. */
  color?: string;
}

export interface Lyrics {
  lyrics: string[];
  sections: LyricSection[];
  groups: MusicGroup[];
  [key: string]: unknown;
}

/** Type an uploaded file can take. Extension decides the family; the only
 *  meaningful override is `backgroundVideo` for a video file. */
export type UploadableAssetType = 'image' | 'video' | 'backgroundVideo' | 'audio';

/** Input of `assets.createFile()`. Supported extensions: `.png .jpg .jpeg .bmp`
 *  (image), `.mp4 .mov` (video), `.mp3 .wav .aac` (audio). */
export interface CreateAssetFileInput {
  /** File name WITH extension — it decides the asset type. */
  filename: string;
  /** File bytes, base64 (a `data:` URL is accepted too). */
  contentBase64?: string;
  /** http(s) URL the HOST downloads. Requires `net:connect` on top of
   *  `assets:write`, since the fetch happens on the plugin's behalf. */
  sourceUrl?: string;
  title?: string;
  author?: string | null;
  /** Defaults to the family of the extension. */
  type?: UploadableAssetType;
  /** Destination folder guid; omit/null for the category root. */
  parent?: string | null;
  /** Custom category uuid; a native id (or omitted) means the type's own tab. */
  category?: string | null;
  /** Video normalization: `false` skips it entirely (default true). */
  optimize?: boolean;
  /** `false` allows the cheap remux but refuses the costly re-encode. */
  allowEncode?: boolean;
}

/** Input of `assets.createMusic()`. `sections` is the recommended form — it is
 *  what the app projects, and `lyrics` is derived from it. */
export interface CreateMusicInput {
  title: string;
  artist?: string | string[] | null;
  sections?: LyricSection[];
  /** Plain verses, used only when `sections` is absent. */
  lyrics?: string[];
  groups?: MusicGroup[];
  /** Musical key, e.g. `"G"`. */
  key?: string;
  isrc?: string;
  /** Raw LRC text or a JSON array of per-verse timecodes. */
  syncedLyrics?: string;
  /** Per-verse timecodes in seconds (`null` = unsynced verse). */
  timecodes?: (number | null)[];
  /** Cover art, base64 (a `data:` URL is accepted too). */
  thumbnailBase64?: string;
  /** Cover art URL the host downloads. */
  thumbnailUrl?: string;
  parent?: string | null;
  category?: string | null;
}

/** Input of `assets.setLyrics()` — same structured payload as creation. */
export interface SetLyricsInput {
  sections?: LyricSection[];
  lyrics?: string[];
  groups?: MusicGroup[];
  syncedLyrics?: string;
  timecodes?: (number | null)[];
}

// ── Lyric provider (spresenter.lyrics.registerProvider) ─────

/** What the app asks when the user types in the music search box. */
export interface LyricSearchRequest {
  /** The raw text typed by the user (already trimmed, never empty). */
  query: string;
}

/**
 * One row of a provider's search listing. Mirrors what the app's own catalog
 * returns, so results from a plugin render exactly like the built-in ones.
 */
export interface LyricSearchResult {
  /** Song title. `title` is accepted as an alias. */
  name: string;
  /** The song's id **in your service**. Opaque to Spresenter: it comes straight
   *  back to you in `getLyrics`, and is the reliable way to fetch the exact
   *  track the user picked (matching by title/artist is guesswork). */
  id?: string;
  artists?: string[];
  isrc?: string;
  album?: {
    name?: string;
    /** Cover art. A list of urls or of `{ url, width?, height? }`; the app uses
     *  the first entry as the row's thumbnail. */
    thumbnail?: (string | { url: string; width?: number; height?: number })[];
  };
}

/**
 * What the app asks when the user selected a song and wants its lyrics. When
 * the song came from **your** listing, `id` is the one you returned; when it
 * came from somewhere else (the app's catalog, another provider) there is no
 * `id` and you match on title/artist/isrc.
 */
export interface LyricRequest {
  title: string;
  /** Primary artist, as shown in the app. */
  artist?: string;
  /** Every artist, when the source listed more than one. */
  artists?: string[];
  isrc?: string;
  /** Your own song id — present only when the listing came from this provider. */
  id?: string;
}

/**
 * The lyrics your provider found. Return `null` for "I don't have this song" —
 * that is not an error, and the app just moves on to the next provider.
 *
 * Prefer `sections`: it is the structured form the app projects (one slide per
 * section), and `lyrics` is derived from it. Use `lyrics` alone when your source
 * has no structure to give.
 */
export interface LyricProviderResult {
  /** Plain verses (one per slide). Ignored when `sections` is given. */
  lyrics?: string[];
  /** Structured sections — verse/chorus/…, groups, chords, comments. */
  sections?: LyricSection[];
  groups?: MusicGroup[];
  /** Raw LRC text, or a JSON array of per-verse timecodes. */
  syncedLyrics?: string;
  /** Per-verse timecodes in seconds (`null` = unsynced verse). */
  timecodes?: (number | null)[];
}

/** Definition passed to `spresenter.lyrics.registerProvider()`. */
export interface LyricProviderDef {
  /** Unique within the plugin (a plugin may register more than one provider). */
  id: string;
  /** Label shown as the group header in the search list and in the lyric
   *  provider selector. Defaults to the plugin's name. */
  name?: string;
  /** lucide icon name (renderer allowlist; fallback = puzzle). */
  icon?: string;
  /** Orders providers among themselves (higher first). Default 0. */
  priority?: number;
  /** Answers the search box. Omit it to be a **lyrics-only** provider: you are
   *  still asked for the lyrics of songs listed by others, but contribute no
   *  rows of your own. */
  search?: (req: LyricSearchRequest) => LyricSearchResult[] | Promise<LyricSearchResult[]>;
  /** Returns the lyrics, or `null` when this provider doesn't have the song. */
  getLyrics: (req: LyricRequest) => LyricProviderResult | null | Promise<LyricProviderResult | null>;
}

/** Input of `assets.createFolder()`. */
export interface CreateFolderInput {
  title: string;
  /** Tab the folder belongs to: `image`, `video`, `audio`, `music`, … or a
   *  custom category uuid. */
  category: string;
  /** Parent folder guid (nesting); omit for the category root. */
  parent?: string | null;
}

export interface Theme {
  [key: string]: unknown;
}

/** A single unit of content rendered on a layer. */
export interface Presentation {
  title?: string;
  asset: Asset;
  theme?: Theme;
  props?: Record<string, unknown>;
}

export interface MediaState {
  playing: boolean;
  loop: boolean;
  time: number;
}

export interface TimerState {
  endTime: number | null;
  remainingMs: number | null;
  running: boolean;
  allowNegative: boolean;
  mode: 'duration' | 'target' | null;
  format: string;
}

export interface SetlistSummary {
  id: string;
  name?: string;
  [key: string]: unknown;
}

export type ActiveSetlist = Record<string, unknown>;

/**
 * Endereço de um grupo da programação: o índice do grupo, ou `'orphans'` — a
 * lista de assets soltos que a sidebar desenha abaixo dos grupos.
 */
export type SetlistGroupRef = number | 'orphans';

/** Posição de um item na programação. */
export interface SetlistItemRef {
  group: SetlistGroupRef;
  index: number;
}

export interface AddSetlistItemInput {
  /** guid do asset, ou o id do Worshipwide (`worshipwide/<arquivo>`). */
  assetGuid: string;
  /** Grupo de destino. Omitido, cria um grupo novo para o item. */
  group?: SetlistGroupRef;
  /** Título do grupo criado quando `group` é omitido. */
  groupName?: string;
  /** Posição dentro do grupo. Omitida, entra no fim. */
  index?: number;
}

/** Ou o par grupo+índice, ou a posição ACHATADA que o operador conta na tela
 *  (só os tipos que a sidebar desenha — igual ao protocolo posicional MIDI). */
export type SelectSetlistItemInput =
  | { group: SetlistGroupRef; index: number }
  | { position: number };

export interface SetlistGroupPatch {
  title?: string;
  /** `null` volta ao padrão. */
  color?: string | null;
  icon?: string | null;
}

/** Um painel da dock do app de controle. */
export interface PanelInfo {
  id: string;
  title: string;
  /** `core` | `plugin` | `live` | `mixer` | `custom` */
  kind: string;
  /** Está no layout. */
  open: boolean;
  /** Está no layout E à vista — aba ATIVA de um grupo visível, sem outro grupo
   *  maximizado por cima. Aberto como aba inativa conta como invisível. */
  visible: boolean;
  /** `grid` (ancorado), `floating` ou `popout`. Ausente se fechado. */
  location?: string;
  /** id do grupo do dockview — mesmo grupo = abas irmãs. */
  groupId?: string;
  closable: boolean;
  /** Indisponível por licença/configuração (ex.: mixer sem PRO). */
  gated: boolean;
}

/**
 * Uma COMPOSIÇÃO (cena) salva: o retrato das camadas — definições, mixer, rack de
 * efeitos, master e o conteúdo de cada camada, por saída.
 *
 * Os contadores vêm do resumo gravado no asset (e não do manifesto) para listar
 * o catálogo sem abrir arquivo nenhum; `null` = composição salva por uma versão
 * que ainda não gravava aquele número.
 */
export interface CompositionSummary {
  guid: string;
  title: string;
  /** Quantas camadas a cena tem. */
  layers: number | null;
  /** Quantas saídas ela cobre. */
  outputs: number | null;
  /** Camadas COM conteúdo na saída 0 quando ela foi salva. */
  filledLayers: number | null;
  /** Pasta do explorador (guid), ou `null` na raiz. */
  folder: string | null;
  /** Miniatura composta (caminho servido pelo app). */
  thumbnail: string;
}

export interface OpenPanelOptions {
  /** Abre como grupo flutuante em vez de ancorado. */
  float?: boolean;
  /** Abre em relação a outro painel ABERTO. */
  reference?: string;
  /** Onde, em relação ao `reference`. `within` = aba irmã. */
  direction?: 'left' | 'right' | 'above' | 'below' | 'within';
}

/** @deprecated renamed to `SetlistSummary`. */
export type EventSummary = SetlistSummary;
/** @deprecated renamed to `ActiveSetlist`. */
export type ActiveEvent = ActiveSetlist;

/** Real-time patch applied to a live theme element (by id), without reloading. */
export interface ElementPatch {
  /** Replace the element's text (TEXT) — goes through the template/markdown pipeline. */
  text?: string;
  /** Raw HTML: render the element freely, bypassing template/markdown. */
  html?: string;
  /** Merge into the element's css (color, size, position, …). */
  css?: Record<string, string | number>;
  /** Toggle visibility. */
  visible?: boolean;
  /** Swap the source (IMAGE/VIDEO). */
  src?: string;
}

/** Chainable handle to a live element — modify it freely (text, style, html…). */
export interface ElementHandle {
  readonly id: string;
  /** Apply an arbitrary patch. */
  patch(p: ElementPatch): ElementHandle;
  setText(text: string): ElementHandle;
  setHtml(html: string): ElementHandle;
  setStyle(css: Record<string, string | number>): ElementHandle;
  setSrc(src: string): ElementHandle;
  show(): ElementHandle;
  hide(): ElementHandle;
}

export type ApiScope =
  | 'outputs:read'
  | 'live:read'
  | 'live:write'
  | 'assets:read'
  /** Criar conteúdo na biblioteca: arquivo, música com letra e pasta. */
  | 'assets:write'
  | 'media:read'
  | 'media:write'
  | 'setlists:read'
  /** Escrever setlist: biblioteca (.spe) e a programação da setlist ATIVA. */
  | 'setlists:write'
  | 'timer:read'
  | 'timer:write'
  /** Ler o layout de painéis do app de controle. */
  | 'ui:read'
  /** Abrir/fechar/selecionar/ancorar painéis do app de controle. */
  | 'ui:write'
  /** Ler a central de notificações desta máquina. */
  | 'notifications:read'
  /** Publicar/marcar/apagar notificações — aparece na tela de quem opera. */
  | 'notifications:write'
  /** Listar os plugins instalados e as ações que cada um expõe. */
  | 'plugins:read'
  /** Executar uma ação exposta por OUTRO plugin. */
  | 'plugins:invoke'
  /** Só-plugin: abrir conexões de rede (WebSocket) via `spresenter.net`. */
  | 'net:connect';

export interface PluginPanelDef {
  id: string;
  title: string;
  icon?: string;
}

export interface PluginManifest {
  id: string;
  name: string;
  version: string;
  description?: string;
  author?: string;
  minAppVersion?: string;
  sdk?: string;
  main: string;
  ui?: string;
  permissions: ApiScope[];
  panels?: PluginPanelDef[];
  /** Start the logic process at boot (needed for automation nodes / background). */
  background?: boolean;
}

/** A field in an automation node's config form. */
export interface AutomationNodeField {
  type: 'string' | 'number' | 'boolean' | 'select';
  label?: string;
  default?: unknown;
  hint?: string;
  /** Options for `type: 'select'` (string or `{ value, label }`). */
  options?: (string | { value: string; label: string })[];
}

/** Definition passed to spresenter.automation.registerNode(). */
export interface AutomationNodeDef {
  /** Unique within the plugin. */
  id: string;
  name: string;
  description?: string;
  /** Category key in the "add node" menu. Defaults to 'plugins'. Use a key
   *  declared via `registerCategory` to group under a custom section. */
  category?: string;
  config?: Record<string, AutomationNodeField>;
  /** Runs when an automation fires this node. Receives the trigger payload
   *  and the node's configured values. */
  execute: (payload: any, config: any) => void | Promise<void>;
}

/** A custom category for the "add node" menu, declared via registerCategory(). */
export interface AutomationCategoryDef {
  /** Grouping key referenced by node `category`. */
  key: string;
  /** Human label shown in the menu. */
  label: string;
  /** lucide icon name (renderer allowlist; fallback = puzzle). */
  icon?: string;
}

/** A field on a trigger, used to filter which events run the automation. */
export interface AutomationTriggerField {
  /** Payload key this field reads/filters on. */
  name: string;
  label?: string;
  type: 'string' | 'number' | 'boolean' | 'select';
  /** Options for `type: 'select'`. */
  options?: (string | { value: string; label: string })[];
}

/** Definition passed to spresenter.automation.registerTrigger(). The plugin
 *  fires it at runtime with emitTrigger(id, payload). */
export interface AutomationTriggerDef {
  /** Unique within the plugin. */
  id: string;
  name: string;
  description?: string;
  /** Category key in the "add node" menu. Defaults to 'plugins'. */
  category?: string;
  /** Fields exposed as per-field filters on the trigger node. */
  fields?: AutomationTriggerField[];
  /** Example payload shown in the editor. */
  samplePayload?: Record<string, unknown>;
}

// ── Central de notificações ──────────────────────────────────

export type NotificationLevel = 'info' | 'success' | 'warning' | 'error';

/** Um cartão da central de notificações (o sino da barra de título). */
export interface AppNotification {
  id: string;
  title: string;
  body: string;
  level: NotificationLevel;
  /** ISO. Do servidor quando veio do painel; local quando nasceu na máquina. */
  sentAt: string;
  /** Quem enviou (nome do plugin, do token ou da pessoa no painel). */
  from: string | null;
  read: boolean;
}

/** O que se manda para `spresenter.notifications.publish(...)`. */
export interface PublishNotificationInput {
  title: string;
  body: string;
  /** Default: 'info'. Os quatro níveis são também os quatro tipos de toast. */
  level?: NotificationLevel;
  /** Default: o nome do plugin. */
  from?: string;
  /** Id próprio, para reenvio idempotente — a central deduplica por ele. */
  id?: string;
  /** ISO. Default: agora. A central ordena por esta data. */
  sentAt?: string;
}

// ── Ações de plugin (chamáveis pela API por id único) ─────────

/** O que o handler sabe sobre a chamada que o acordou. */
export interface PluginRequestMeta {
  /** `GET`/`POST` (o verbo da rota) ou `PLUGIN` (veio de outro plugin). */
  method: string;
  /** A query string da chamada. Num `GET`, é também o payload. */
  query: Record<string, string>;
  /** Nome do token que autenticou — útil para o plugin logar a origem. */
  token?: string;
}

/** Metadados opcionais de uma ação, mostrados em `GET /api/v1/plugins`. */
export interface PluginRequestDef {
  name?: string;
  description?: string;
  /** Exemplo do corpo aceito. Documentação, não validação. */
  sample?: Record<string, unknown>;
}

/** Uma ação exposta por um plugin. */
export interface PluginActionSummary {
  action: string;
  name?: string;
  description?: string;
  sample?: Record<string, unknown>;
}

/** Um plugin instalado nesta máquina, como a API o descreve. */
export interface PluginSummary {
  id: string;
  name: string;
  version: string;
  description?: string;
  author?: string;
  enabled: boolean;
  runtime: 'running' | 'stopped' | 'crashed';
  background: boolean;
  permissions: ApiScope[];
  actions: PluginActionSummary[];
}
